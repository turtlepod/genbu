<?php
/* === CHILD THEME FUNCTIONS === */

/* Setup Child Theme */
add_action( 'after_setup_theme', 'my_child_theme_setup', 11 );

/**
 * Setup Function
 * Add your hooks and action inside this function.
 */
function my_child_theme_setup(){

}

/* === Add your custom functions below. === */

